import logging
import time

logging.basicConfig(level=logging.INFO)
for i in range(500):
    print("John")
